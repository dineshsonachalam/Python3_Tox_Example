import os
from setuptools import setup



setup(
    name = "tox-example",
    version = "0.0.1",
    author = "Dinesh",
    packages=['tests']
)
